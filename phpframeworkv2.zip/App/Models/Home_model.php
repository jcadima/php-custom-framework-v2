<?php
namespace App\Models;

class Home_Model extends \Core\Model {
	public function Index() {
		return;
	}
}