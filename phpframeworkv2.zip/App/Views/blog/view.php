<div>
	<div class="well">
			<h3><?php echo $postid['title']; ?></h3>
			<hr />
			<p><?php echo $postid['body']; ?></p>

	</div>
</div>