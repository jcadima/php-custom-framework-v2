

<div class="footer-cont">
    <div class="container">
	    <div class="col-md-6">
	    	<p class="text-center"><a href="http://juancadima.com/projects/">Return to Projects</a></p>
	    </div>
	    
	    <div class="col-md-6">
	    	<p class="text-center"><a href="http://juancadima.com/">Return to Home</a></p>
	    </div>
    </div>
</div>
    
    
</body>
</html>