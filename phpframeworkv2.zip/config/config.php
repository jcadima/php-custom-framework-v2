<?php

// Define DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "phpframework");

// Define URL
define("ROOT_PATH", "/");

// set URL  ex:  http://example.com/
define("ROOT_URL", "http://phpframeworkv2.dev/"); // 